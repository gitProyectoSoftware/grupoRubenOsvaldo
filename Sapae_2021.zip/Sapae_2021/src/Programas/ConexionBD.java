
package Programas;

import java.sql.*;

public class ConexionBD {

    Connection con = null;

    public Connection conecta() {
        String dbURL = "jdbc:mysql://localhost:3306/sapae_2021";
        String user = "root";
        String clave = "";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(dbURL, user, clave);
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("error en conexion :" + ex.getMessage());
        }
        
        return con;
    }
}
