
package Programas;

import Modelo.Vehiculos;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cvehiculos {
    ConexionBD cone= new ConexionBD();
    
    
    
    public ArrayList listarVeh()
    {
       
            ArrayList <Vehiculos> lveh=new ArrayList();
            Connection con;
            con=cone.conecta();
            String sql="select * from vehiculos";
             try {
            Statement smt=con.createStatement();
            ResultSet rs=smt.executeQuery(sql);
            while(rs.next())
            {
            Vehiculos veh=new Vehiculos();
            veh.setPlaca(rs.getString("placa"));
            veh.setClase(rs.getString("clase"));
            veh.setTipo(rs.getString("tipo"));
            veh.setMarca(rs.getString("marca"));
            veh.setModelo(rs.getString("modelo"));
            veh.setMotor(rs.getInt("motor"));
            veh.setChasis(rs.getInt("chasis"));
            veh.setColor(rs.getString("color"));
            veh.setAnio(rs.getInt("anio"));
            veh.setProcedencia(rs.getString("procedencia"));
            lveh.add(veh);
            }
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Cvehiculos.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lveh;
    }
}
