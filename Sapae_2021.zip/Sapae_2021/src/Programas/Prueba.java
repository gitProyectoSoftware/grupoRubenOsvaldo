package Programas;

import java.sql.*;

public class Prueba {

    public static void main(String arg[]) {
        ConexionBD cone = new ConexionBD();
        Connection con;
        con = cone.conecta();
        if (con != null) {
            System.out.println("se conecto a la BD ");
        } else {
            System.out.println(" no se conecto wey");
        }
    }
}
